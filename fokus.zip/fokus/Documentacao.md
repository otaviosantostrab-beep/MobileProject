# Otavio.fokus
# Principais comandos do React-native
1. npx create-expo-app@3 fokus -> Cria uma projeto novo em expo na versão 3 chamado fokus.
2. npm run web [npm start]-> Inicializar o app no navegador.
3. npm run reset-project -> Reseta o app para a versão limpa.
4. npm start -> Inicializa o projeto e solicita em qual plataforma você irá rodar.
5. npm install -> Instala todas as dependências necessárias para o projeto rodar.


# Componentes do react-native
1. <View> -> Serve como um container, parecido como a <div> no html.
2. <Text> -> Serve para inserir um texto no app. Parecido com o <p>.
3. StyleSheet -> Utilizado para criar uma estilização.

# Métodos utilizados no react native
1. require() -> Faz com que você consiga passar um caminho da img que está dentro do projeto. 


# Principais comandos do terminal
1. cd nomedapasta -> Altera/muda o diretório atual.
2. cls -> Limpa o terminal.
3. cd .. -> Volta uma pasta.

# Métodos, propriedades e hooks do Timer.
1. useRef
2. setInterval()
3. clearInterval()
4. current


